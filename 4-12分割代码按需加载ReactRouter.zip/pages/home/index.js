import React from 'react';

export default function PageHome() {
  return <div>Page Home</div>
}
